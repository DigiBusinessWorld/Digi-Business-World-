<!DOCTYPE html>
<html>
<head>
    
     <meta name="google-site-verification" content="5rHooKUc9DJvnWXr-4hVp7ZJDAZNwQObim4jH3OF1ao">
     
     <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#333">
    <title>Digital Marketing Company in Delhi - Digital Marketing Company in Delhi | Digital Marketing Company in Dwarka | Digital Marketing Agency in Delhi | Digital Marketing Agency in Dwarka</title>
    <meta name="description" content="In the course of recent years, Digital marketing agency in dwarka burned through 100s of hours contemplating web journals, aides, and Google Patents.">
    <meta name="keyword" content="Digital Marketing Company in Delhi, Digital Marketing Company in Dwarka, Digital Marketing Agency in Delhi, Digital Marketing Agency in Dwarka">
    <meta name="robots" content="index,follow,all" />
    <meta name="googlebot" content="index,follow">
    <meta name="YahooSeeker" content="index, follow" />
    <meta name="Yahoobot" content="Index, Follow"/>
    <meta name="MSNbot" content="index, follow"/>
    <meta name="country" content="India">
    <meta name="state" content="Delhi">
    <meta name="city" content="Delhi">
    <meta name="language" content="English"/>
    <?php include('header.php'); 
	
if (isset($_POST['submit'])) {
   
    $username = $_POST['username'];
    $mobile_no = $_POST['mobile_no'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];


  
$admin_msg = "Kindly Contact to the Client using following details \n Client Name : Mr ".$username."\n  Contact No. : ".$mobile_no."\n  Email : ".$email."\n  Subject :".$subject."\n  Message :".$message;

$to="ranjana.digibusinessworld@gmail.com";
$from=$email;

$subject="Enquiry From Website (Digi Business World) By ".$username;
$header  = "From:".$from." \r\n";
mail($to,$subject,$admin_msg,$header);

 echo '<script>alert("Enquiry Submited Successfully,We will get in touch with you shortly.")</script>';		
		            echo '<script>window.location.href="contact.php";</script>';
}
?>
	<!--Banner Section-->
    <div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:1600px;height:560px;overflow:hidden;visibility:hidden;">
        <!-- Loading Screen -->
        <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
            <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="img/spin.svg" />
        </div>
        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:1600px;height:560px;overflow:hidden;">
        	<div>
                <img data-u="image" data-src="img/b1.png" />
                <div data-ts="flat" data-p="540" data-po="40% 50%" style="left:0px;top:0px;width:1600px;height:560px;position:absolute;">
                    <div data-to="50% 50%" data-ts="preserve-3d" data-t="6" style="left:350px;top:360px;width:900px;height:500px;position:absolute;">
                        <svg viewbox="0 0 800 60" data-to="50% 50%" width="800" height="60" data-t="7" style="left:0px;top:-70px;display:block;position:absolute;opacity:0;font-family:'Roboto Condensed',sans-serif;font-size:60px;font-weight:700;letter-spacing:0.05em;overflow:visible;">
                            <text fill="#454447" stroke="#ff9500" stroke-width="2" text-anchor="middle" x="200" y="200">Digi Business World
                            </text>
                        </svg>
                        <svg viewbox="0 0 800 100" width="800" height="100" data-t="9" style="left:40px;top:250px;display:block;position:absolute;opacity:0;font-family:'Roboto Condensed',sans-serif;font-size:80px;font-weight:900;letter-spacing:0.5em;overflow:visible;">
                            <text fill="rgba(255,255,255,0.7)" stroke="#ff9500" text-anchor="middle" x="400" y="100">DIGITAL MARKETING
                            </text>
                        </svg>
                    </div>
                </div>
            </div>
            
            <div style="background-color:#d3890e;">
                <img data-u="image" style="opacity:0.8;" data-src="img/b2.png" />
                <div data-ts="flat" data-p="275" data-po="40% 50%" style="left:150px;top:40px;width:800px;height:300px;position:absolute;">
                    <div data-to="50% 50%" data-t="0" style="left:50px;top:520px;width:400px;height:100px;position:absolute;color:#f0a329;font-family:'Roboto Condensed',sans-serif;font-size:84px;font-weight:900;letter-spacing:0.5em;">Digi </div>
                    <div data-to="50% 50%" data-t="1" style="left:50px;top:540px;width:400px;height:100px;position:absolute;opacity:0.5;color:#f0a329;font-family:'Roboto Condensed',sans-serif;font-size:84px;font-weight:900;letter-spacing:0.5em;">Digi</div>
                    <div data-to="50% 50%" data-t="2" style="left:50px;top:560px;width:400px;height:100px;position:absolute;opacity:0.25;color:#f0a329;font-family:'Roboto Condensed',sans-serif;font-size:84px;font-weight:900;letter-spacing:0.5em;">Digi</div>
                    <div data-to="50% 50%" data-t="3" style="left:50px;top:580px;width:400px;height:100px;position:absolute;opacity:0.125;color:#f0a329;font-family:'Roboto Condensed',sans-serif;font-size:84px;font-weight:900;letter-spacing:0.5em;">Digi</div>
                    <div data-to="50% 50%" data-t="4" style="left:50px;top:600px;width:400px;height:100px;position:absolute;opacity:0.06;color:#f0a329;font-family:'Roboto Condensed',sans-serif;font-size:84px;font-weight:900;letter-spacing:0.5em;">Digi</div>
                    <div data-to="50% 50%" data-t="5" style="left:50px;top:710px;width:700px;height:100px;position:absolute;color:#f0a329;font-family:'Roboto Condensed',sans-serif;font-size:64px;font-weight:900;letter-spacing:0.5em;">Business World</div>
                </div>
            </div>

            <div>
                <img data-u="image" data-src="img/b3.jpg" />
                <div data-ts="flat" data-p="1080" style="left:0px;top:0px;width:1600px;height:560px;position:absolute;">
                    <div data-to="50% 50%" data-t="14" style="left:690px;top:270px;width:600px;height:150px;position:absolute;opacity:3.0px;color:#000;font-weight: 600; font-family:Georgia,'Times New Roman',Times,serif;font-size:50px;line-height:1.2;letter-spacing:0.1em;">Our Portal</div>
                    <img data-to="50% 50%"/>
                    <img data-to="50% 50%" data-t="16" style="left:70px;top:340px;width:500px;height:90px;position:absolute;opacity:3.0;max-width:500px;" data-src="img/world.png" />
                </div>
            </div>
        </div><a data-scale="0" href="https://digibusinessworld.com" style="display:none;position:absolute;">Digital Marketing</a>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb132" style="position:absolute;bottom:24px;right:16px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
            <div data-u="prototype" class="i" style="width:12px;height:12px;">
                <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <circle class="b" cx="8000" cy="8000" r="5800"></circle>
                </svg>
            </div>
        </div>
        <!-- Arrow Navigator -->
        <div data-u="arrowleft" class="jssora051" style="width:55px;height:55px;top:0px;left:25px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="11040,1920 4960,8000 11040,14080 "></polyline>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora051" style="width:55px;height:55px;top:0px;right:25px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="4960,1920 11040,8000 4960,14080 "></polyline>
            </svg>
        </div>
    </div>
	<!--End Banner Section-->
	
	<!-- Services Section -->
    <section class="services-section">
		<div class="auto-container">
			<div class="row clearfix">
				
				<!-- Service Block -->
				<div class="service-block col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="inner-content">
							<div class="icon-box">
								<span class="icon flaticon-rocket"></span>
							</div>
							<h5>Greate Results</h5>
							<div class="text">We have seen great successes <br> with everyone companies.</div>
							<span class="side-icon flaticon-rocket"></span>
						</div>
						
						<!-- Overlay Box -->
						<div class="overlay-box">
							<div class="overlay-inner">
								<div class="content">
									<div class="left-top-icon flaticon-rocket"></div>
									<div class="overlay-icon flaticon-rocket"></div>
									<h5><a href="#!">Greate Results</a></h5>
									<div class="text">We have seen great successes <br> with everyone companies.</div>
									<a href="#!" class="arrow"><span class="icon flaticon-right-arrow-2"></span></a>
								</div>
							</div>
						</div>
						
					</div>
				</div>
				
				<!-- Service Block -->
				<div class="service-block col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInLeft" data-wow-delay="150ms" data-wow-duration="1500ms">
						<div class="inner-content">
							<div class="icon-box">
								<span class="icon flaticon-world"></span>
							</div>
							<h5>Business Worth</h5>
							<div class="text">Every business and industry requires an approach.</div>
							<span class="side-icon flaticon-world"></span>
						</div>
						
						<!-- Overlay Box -->
						<div class="overlay-box">
							<div class="overlay-inner">
								<div class="content">
									<div class="left-top-icon flaticon-world"></div>
									<div class="overlay-icon flaticon-world"></div>
									<h5><a href="#!">Business Worth</a></h5>
									<div class="text">Every business and industry <br> requires an approach.</div>
									<a href="#!" class="arrow"><span class="icon flaticon-right-arrow-2"></span></a>
								</div>
							</div>
						</div>
						
					</div>
				</div>
				
				<!-- Service Block -->
				<div class="service-block col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1500ms">
						<div class="inner-content">
							<div class="icon-box">
								<span class="icon flaticon-connect"></span>
							</div>
							<h5>Keep Your Growth</h5>
							<div class="text">You make sure you know how <br> campaign is performing.</div>
							<span class="side-icon flaticon-connect"></span>
						</div>
						
						<!-- Overlay Box -->
						<div class="overlay-box">
							<div class="overlay-inner">
								<div class="content">
									<div class="left-top-icon flaticon-connect"></div>
									<div class="overlay-icon flaticon-connect"></div>
									<h5><a href="#!">Keep Your Groth</a></h5>
									<div class="text">You make sure you know how <br> campaign is performing.</div>
									<a href="#!" class="arrow"><span class="icon flaticon-right-arrow-2"></span></a>
								</div>
							</div>
						</div>
						
					</div>
				</div>
				
				<!-- Service Block -->
				
			</div>
		</div>
	</section>
	<!-- End Services Section -->
	
	<!-- About Section -->
    <section class="about-section">
		<!-- Pattern One -->
		<div class="left-patterm paroller" data-paroller-factor="0.20" data-paroller-factor-lg="0.20" data-paroller-type="foreground" data-paroller-direction="vertical" style="background-image:url(images/icons/about.png)"></div>
		<div class="auto-container">
			<div class="row clearfix">
				
				<!-- Content Column -->
				<div class="content-column col-lg-5 col-md-12 col-sm-12">
					<div class="inner-column">
						<!-- Sec Title -->
						<div class="sec-title">
							<div class="title">ABOUT US</div>
							<h2>Digi Business world</h2>
						</div>
						<div class="bold-text"> Digi Business World Internet Services strives to be the complete business solutions provider for our customers using advanced technologies to serve corporations all over the world.</div>
						<div class="text">Digi Business world  is a complete web solutions company providing multi-dimensional IT services internet strategy solutions, design solutions and software development, Content Management System (CMS), eCommerce Solution, SearchEngine Optimization (SEO), PayPer Click Management and Email Marketing services for corporations across the india.</div>
						<a href="about.php" class="theme-btn btn-style-three"><span class="txt">Learn More</span></a>
					</div>
				</div>
				
				<!-- Image Column -->
				<div class="image-column col-lg-7 col-md-12 col-sm-12">
					<div class="inner-column parallax-scene-1">
						<div data-depth="0.30" class="image">
							<img src="images/resource/about.png" alt ="Digi Business World About Us" />
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- End About Section -->
	
	<!-- Services Section -->
	<section class="services-section-two">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title centered">
				
				<h2>Our Services</h2>
				<div class="title">We are Providing Best Services</div>
			</div>
			
			<div class="three-item-carousel owl-carousel owl-theme">
				
				<!-- Service Block Two -->
				<div class="service-block-two">
					<div class="inner-box">
						<div class="patern-layer" style="background-image: url(images/icons/service-curve.png)"></div>
						<div class="icon-box">
							<span class="icon flaticon-statistics"></span>
						</div>
						<h5><a href="seo-service.php">SEO SERVICE</a></h5>
						<div class="text">You can provide the answers that your potential customers are trying to find, so you can become the industry.</div>
						<a href="seo-service.php" class="read-more">Read More</a>
					</div>
				</div>
				
				<!-- Service Block Two -->
				<div class="service-block-two">
					<div class="inner-box">
						<div class="patern-layer" style="background-image: url(images/icons/service-curve.png)"></div>
						<div class="icon-box">
							<span class="icon flaticon-presentation"></span>
						</div>
						<h5><a href="ppc-service.php">PPC Services</a></h5>
						<div class="text">Create and manage top-performing social campaigns and start developing a dedicated customer fan base.</div>
						<a href="ppc-service.php" class="read-more">Read More</a>
					</div>
				</div>
				
				<!-- Service Block Two -->
				<div class="service-block-two">
					<div class="inner-box">
						<div class="patern-layer" style="background-image: url(images/icons/service-curve.png)"></div>
						<div class="icon-box">
							<span class="icon flaticon-chart"></span>
						</div>
						<h5><a href="website-designing.php">Website Services</a></h5>
						<div class="text">Create, publish, and promote engaging content to generate more traffic and build a dedicated community.</div>
						<a href="website-designing.php" class="read-more">Read More</a>
					</div>
				</div>
				
				<!-- Service Block Two -->
				<div class="service-block-two">
					<div class="inner-box">
						<div class="patern-layer" style="background-image: url(images/icons/service-curve.png)"></div>
						<div class="icon-box">
							<span class="icon flaticon-statistics"></span>
						</div>
						<h5><a href="amazon-flipkart-services.php">Amazon/Flipkart Service</a></h5>
						<div class="text">You can provide the answers that your potential customers are trying to find, so you can become the industry.</div>
						<a href="amazon-flipkart-services.php" class="read-more">Read More</a>
					</div>
				</div>
				
				<!-- Service Block Two -->
				<div class="service-block-two">
					<div class="inner-box">
						<div class="patern-layer" style="background-image: url(images/icons/service-curve.png)"></div>
						<div class="icon-box">
							<span class="icon flaticon-presentation"></span>
						</div>
						<h5><a href="social-media-optimization.php">Social Media Service</a></h5>
						<div class="text">Create and manage top-performing social campaigns and start developing a dedicated customer fan base.</div>
						<a href="social-media-optimization.php" class="read-more">Read More</a>
					</div>
				</div>
				
			</div>
			
		</div>
	</section>
	<!-- End Services Section -->
	
	<!-- Testimonial Section -->
	<section class="testimonial-section">
		<!-- Paroller Pattern -->
		<div class="right-patterm paroller" data-paroller-factor="-0.40" data-paroller-factor-lg="0.50" data-paroller-type="foreground" data-paroller-direction="vertical" style="background-image:url(images/icons/testimonial-paroller.png)"></div>
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title centered">
				<div class="title">Testimonials</div>
				<h2>What Client Say About Our <br> Company</h2>
			</div>
			
			<!-- Inner Container -->
			<div class="inner-container">
				<div class="pattern-image" style="background-image: url(images/icons/testimonial-1.png)"></div>
				<div class="pattern-image-two" style="background-image: url(images/icons/testimonial-3.png)"></div>
				<div class="pattern-image-three" style="background-image: url(images/icons/testimonial-2.png)"></div>
				<div class="testimonial-carousel owl-carousel owl-theme">
					
					<!-- Testimonial Block -->
					<div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/resource/kappn.png" alt="" />
							</div>
							<div class="quote-icon flaticon-quote-3"></div>
							<div class="text">Digi Business World is very responsive. They used the time difference between us to their advantage and created a very interactive working relationship.I am very happy with their work, and I look forward working with them on my next project.
</div>
							<div class="lower-box">
								<div class="clearfix">
									<div class="pull-left">
										<div class="author-name">Ankit</div>
										<div class="designation">KAPN</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<!-- Testimonial Block -->
					<div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/resource/author2.png" alt="" />
							</div>
							<div class="quote-icon flaticon-quote-3"></div>
							<div class="text">Great Team to work with, really attentive and react to request immediately. Excellent work and I'm really pleased with the results. They provided so much more than I asked for! I am pleased with my website and the interaction with their representative.</div>
							<div class="lower-box">
								<div class="clearfix">
									<div class="pull-left">
										<div class="author-name">Raj</div>
										<div class="designation">Majoka Industries</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
				</div>
			</div>
			
		</div>
	</section>
	<!-- End Testimonial Section -->
	
	
<?php include('footer.php'); ?>