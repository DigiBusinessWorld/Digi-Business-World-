	<!-- Main Footer -->
    <footer class="main-footer">
		<!--Waves end-->
    	<div class="auto-container">
        	<!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	
                    <!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!-- Footer Column -->
                            <div class="footer-column col-lg-7 col-md-6 col-sm-12">
                                <div class="footer-widget logo-widget">
                                	<h4>About</h4>
									<div class="text">Digi Business World  Services strives to be the complete business solutions provider for our customers using advanced technologies to serve corporations all over the world. Marketers need to build digital relationships and reputation before closing a sale.</div>
									<!-- Social Box -->
									<ul class="social-box">
										<li><a href="https://www.facebook.com/digibusinessworld"  target="_blank" class="fa fa-facebook-f"></a></li>
										<li><a href="#" class="fa fa-linkedin"></a></li>
										<li><a href="#" class="fa fa-twitter"></a></li>
										<li><a href="https://www.instamojo.com/@digibusinessworld"><img src="click-to-pay.png"><span id="siteseal"><script async type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=d895O192AxW0lL2n0tO5BZFn4XcV5QjHsh76ufktB20j1nfDUK0WMkpt6zpu"></script></span></a></li>
									</ul>

								</div>
							</div>
							
							<!-- Footer Column -->
                            <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h4>Services</h4>
									<ul class="list-link">
										<li><a href="seo-service.php">SEO</a></li>
										<li><a href="ppc-service.php">PPC Services</a></li>
										<li><a href="amozon-flipkart-services.php">Amazon/Flipkart Service</a></li>
									</ul>
								</div>
							</div>
							
						</div>
					</div>
					
					<!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
							
							<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget gallery-widget">
									<h4>Services</h4>
									<ul class="list-link">
										<li><a href="social-media-optimization.php">Social Media Service</a></li>
										<li><a href="term-&-condition.php">Term & Condition</a></li>
										<li><a href="privacy-policy.php">Privacy Policy</a></li>
										<li><a href="portfolio.php">Portfolio</a></li>
									</ul>
								</div>
							</div>
							
							<!-- Footer Column -->
                            <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h4>Contact info</h4>
									<ul class="list-style-two">
										<li style="color: #fff;"><span class="icon flaticon-maps-and-flags"></span>B-8, 3rd Floor, Ram Nagar, Near Metro Pillar No 711, Nawada, Uttam Nagar, New Delhi-110059</li>
										
										<li style="color: #fff;"><span class="icon flaticon-call"></span><a href="tel:+91-9625424415" style="color: #fff;">+91-9625424415</a></li>
										
										<li style="color: #fff;"><span class="icon flaticon-email-4"></span><a href="mailto:info@digibusinessworld.com" style="color: #fff;">info@digibusinessworld.com</a></li>

									</ul>
								</div>
							</div>
							
						</div>
					</div>
				
				</div>
			</div>
			
		</div>
	</footer>
	<!-- End Main Footer -->
	
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>

<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/appear.js"></script>
<script src="js/parallax.min.js"></script>
<script src="js/tilt.jquery.min.js"></script>
<script src="js/jquery.paroller.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/validate.js"></script>
<script src="js/wow.js"></script>
<script src="js/nav-tool.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/script.js"></script>
<script src="js/color-settings.js"></script>
<script type="text/javascript">jssor_1_slider_init();
    </script>

<!-- GetButton.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
              whatsapp: "+91-9625424415", // WhatsApp number
            call: "+91-9625424415", // Call phone number
            call_to_action: "Contact us", // Call to action
            button_color: "#2196f3", // Color of button
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "getbutton.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /GetButton.io widget -->
</body>
</html>